package com.example.testeaula2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteAula2Application {

	public static void main(String[] args) {
		SpringApplication.run(TesteAula2Application.class, args);
	}

}
